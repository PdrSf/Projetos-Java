package armas;

public class Adaga extends Armas_mae {
	Adaga(){
		this.setArma(2, 9 , 0);
	}
}
