package armas;

public class Lanca extends Armas_mae {
	Lanca(){
		this.setArma(4, 5, 0);
	}
}
