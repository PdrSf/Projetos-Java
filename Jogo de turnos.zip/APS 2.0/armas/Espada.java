package armas;

public class Espada extends Armas_mae{
	Espada(){
		this.setArma(1, 0, 0);
	}

}
