package armas;

public class Luvas extends Armas_mae {
	Luvas(){
		this.setArma(5, 0, 0);
	}
}
