package narrativa;

public abstract class Narrativa {
	public abstract void narrativa01();
	public abstract void narrativa02();
	public abstract void narrativa03();
	public abstract void narrativa04();
	public void narrativa05() {}
	public void narrativa06() {}

}