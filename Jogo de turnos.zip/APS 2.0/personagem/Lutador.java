package personagem;

public class Lutador extends Amigo{
	public Lutador(){
		super((byte)12, (byte)12, "Lutador" ,49,(byte) 5);
	}

}
