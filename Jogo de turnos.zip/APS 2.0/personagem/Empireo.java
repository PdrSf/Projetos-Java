package personagem;

public class Empireo extends Inimigo{
	public Empireo() {
		super((byte)16, (byte)13, 40, "Empíreo");
	}

}
