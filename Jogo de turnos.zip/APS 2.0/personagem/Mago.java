package personagem;

public class Mago extends Amigo {

	public Mago() {
		super((byte)16, (byte)12, "Mago" ,45,(byte) 15);
		
	}
}
