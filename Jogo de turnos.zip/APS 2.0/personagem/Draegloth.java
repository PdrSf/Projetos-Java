package personagem;

public class Draegloth extends Inimigo {
	public Draegloth() {
		super((byte)14, (byte)10, 20, "Draegloth");
	}
}
