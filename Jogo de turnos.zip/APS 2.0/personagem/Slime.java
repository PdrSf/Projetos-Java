package personagem;

public class Slime extends Inimigo {

	public Slime () {
		super((byte)12, (byte)7, 22, "Slime");

	}
}