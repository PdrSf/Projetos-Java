package personagem;

public class Armadura extends Inimigo {
	public Armadura() {
		super((byte)14, (byte)10, 20, "Armadura");
	}

}
