package personagem;

public class Primata extends Inimigo {
	public Primata() {
		super((byte)16, (byte)13, 40, "O Primata");
	}
}
