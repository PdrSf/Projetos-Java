package personagem;

public class Driade extends Inimigo {
	public Driade() {
		super((byte)16, (byte)13, 40, "Dríade");
	}
}
