package personagem;

public class Espadachim extends Amigo{
	public Espadachim(){
		super((byte)13, (byte)12, "Espadachim" ,46,(byte) 5);
	}

}
