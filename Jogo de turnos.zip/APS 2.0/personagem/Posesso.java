package personagem;

public class Posesso extends Inimigo{
	public Posesso() {
		super((byte)16, (byte)13, 40, "O Possesso");
	}

}
