package personagem;

public class Fantasma extends Inimigo {
	public Fantasma() {
		super((byte)12, (byte)7, 22, "Fantasma");
	}
}
