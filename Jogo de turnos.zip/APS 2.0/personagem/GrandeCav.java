package personagem;

public class GrandeCav extends Inimigo {
	public GrandeCav() {
		super((byte)16, (byte)13, 40, "Grande Cavaleiro");
	}
}
