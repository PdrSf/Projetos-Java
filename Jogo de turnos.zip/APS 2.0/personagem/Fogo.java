package personagem;

public class Fogo extends Inimigo{
	public Fogo() {
		super((byte)14, (byte)10, 20, "Elemental de fogo");
	}
}
