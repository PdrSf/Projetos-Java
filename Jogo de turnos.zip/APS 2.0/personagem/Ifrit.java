package personagem;

public class Ifrit extends Inimigo {
	public Ifrit() {
		super((byte)16, (byte)13, 40, "Ifrit");
	}

}
