package personagem;

public class Acolito extends Inimigo {
	public Acolito() {
		super((byte)16, (byte)10, 33, "Oni");
	}

}
