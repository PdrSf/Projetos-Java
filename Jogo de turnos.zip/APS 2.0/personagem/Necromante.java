package personagem;

public class Necromante extends Inimigo {
	public Necromante() {
		super((byte)16, (byte)13, 40, "Necromante");
	}
}
