package personagem;

public class Golem extends Inimigo{
	public Golem() {
		super((byte)16, (byte)13, 40, "Golem");
	}

}
