package personagem;

public class Javali extends Inimigo{
	public Javali() {
		super((byte)12, (byte)7, 22, "Javali Selvagem");

	}

}
