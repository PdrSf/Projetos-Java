package personagem;

public class Banshee extends Inimigo {
	public Banshee() {
		super((byte)14, (byte)10, 20, "Banshee");
	}

}
