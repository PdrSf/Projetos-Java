package personagem;

public class Gargola extends Inimigo {
	public Gargola(){
		super((byte)16, (byte)13, 40, "Gargola");
	}

}
