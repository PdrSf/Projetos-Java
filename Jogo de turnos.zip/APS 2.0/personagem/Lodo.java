package personagem;

public class Lodo extends Inimigo{
	public Lodo() {
		super((byte)16, (byte)13, 40, "Lodo Ígneo Sanguineo");
	}


}
