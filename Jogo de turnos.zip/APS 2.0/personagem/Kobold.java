package personagem;

public class Kobold extends Inimigo{
	public Kobold() {
		super((byte)12, (byte)7, 22, "Kobold");
	}

}
