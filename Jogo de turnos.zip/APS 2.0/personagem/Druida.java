package personagem;

public class Druida extends Amigo{
	public Druida() {
		super((byte)13, (byte)14, "Druida" ,48,(byte) 8);
	}

}
