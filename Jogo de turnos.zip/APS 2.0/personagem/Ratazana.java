package personagem;

public class Ratazana extends Inimigo{
	public Ratazana() {
		super((byte)12, (byte)7, 22, "Ratazana Gigante");
	}
	
}
