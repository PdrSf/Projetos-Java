package personagem;

public class Harpia extends Inimigo {
	public Harpia() {
		super((byte)16, (byte)10, 33, "Harpia");
	}

}
