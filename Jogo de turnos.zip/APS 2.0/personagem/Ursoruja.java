package personagem;

public class Ursoruja extends Inimigo{
	public Ursoruja() {
		super((byte)16, (byte)10, 33, "Urso Coruja");
	}

}
