package personagem;

public class Cavaleiro extends Inimigo {
	public Cavaleiro() {
		super((byte)14, (byte)10, 20, "Cavaleiro Real");
	}
}
