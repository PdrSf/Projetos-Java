package personagem;

public class Goblins extends Inimigo{
	public Goblins() {
		super((byte)14, (byte)10, 20, "Bando de goblins");
	}

}
