package personagem;

public class Cavalaria extends Inimigo {
	public Cavalaria() {
		super((byte)16, (byte)10, 33, "Cavalaria de Elite");
	}
}
