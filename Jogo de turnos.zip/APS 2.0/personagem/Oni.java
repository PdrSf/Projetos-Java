package personagem;

public class Oni extends Inimigo{
	public Oni() {
		super((byte)16, (byte)10, 33, "Oni");

	}

}
